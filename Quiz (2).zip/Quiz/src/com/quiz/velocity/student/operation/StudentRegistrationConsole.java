package com.quiz.velocity.student.operation;

import java.sql.SQLException;

public interface StudentRegistrationConsole {
	
	public abstract void getStudentDetails() throws SQLException;
}
