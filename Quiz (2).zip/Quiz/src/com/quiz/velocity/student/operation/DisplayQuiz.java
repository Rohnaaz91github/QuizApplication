package com.quiz.velocity.student.operation;

public interface DisplayQuiz {
	
	public abstract void getDisplayQuestion();

}
