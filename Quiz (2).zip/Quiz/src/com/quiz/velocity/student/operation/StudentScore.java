package com.quiz.velocity.student.operation;

import java.sql.SQLException;

public interface StudentScore {
	
	public abstract void getStudentScoreDetails() throws SQLException;

}
