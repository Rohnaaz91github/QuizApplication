package com.quiz.velocity.student.operation;

public interface StudentLoginConsole {
	
	public abstract void StudentLoginDetails();
	
	

}
